import os
import sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("PC_BUILDER_SECRET", "dev-only-change-this-secret")
DB_PATH = os.path.join(os.path.dirname(__file__), "pc_builder.db")

CATEGORIES = {
    "cpu": "Процессор",
    "gpu": "Видеокарта",
    "motherboard": "Материнская плата",
    "ram": "Оперативная память",
    "storage": "Накопитель",
    "psu": "Блок питания",
    "case": "Корпус",
}
CATEGORY_ORDER = ["cpu", "motherboard", "ram", "gpu", "storage", "psu", "case"]

SEED_COMPONENTS = [
    ("cpu", "AMD Ryzen 5 5600", "AMD", 65000, 65, "AM4", "DDR4", "ATX", 0, "6 ядер / 12 потоков; до 4.4 ГГц"),
    ("cpu", "AMD Ryzen 5 7600", "AMD", 105000, 65, "AM5", "DDR5", "ATX", 0, "6 ядер / 12 потоков; до 5.1 ГГц"),
    ("cpu", "AMD Ryzen 7 7800X3D", "AMD", 210000, 120, "AM5", "DDR5", "ATX", 0, "8 ядер / 16 потоков; 3D V-Cache"),
    ("cpu", "Intel Core i5-12400F", "Intel", 70000, 65, "LGA1700", "DDR4", "ATX", 0, "6 ядер / 12 потоков; без встроенной графики"),
    ("cpu", "Intel Core i5-14600K", "Intel", 185000, 125, "LGA1700", "DDR5", "ATX", 0, "14 ядер (6P+8E); разблокированный множитель"),
    ("gpu", "NVIDIA GeForce RTX 4060 8GB", "NVIDIA", 165000, 115, "", "", "", 0, "8 ГБ GDDR6; ориентир для 1080p"),
    ("gpu", "NVIDIA GeForce RTX 4070 SUPER 12GB", "NVIDIA", 310000, 220, "", "", "", 0, "12 ГБ GDDR6X; ориентир для 1440p"),
    ("gpu", "AMD Radeon RX 7600 8GB", "AMD", 145000, 165, "", "", "", 0, "8 ГБ GDDR6"),
    ("gpu", "AMD Radeon RX 7800 XT 16GB", "AMD", 275000, 263, "", "", "", 0, "16 ГБ GDDR6"),
    ("motherboard", "MSI B550M PRO-VDH WIFI", "MSI", 65000, 45, "AM4", "DDR4", "mATX", 0, "AM4; DDR4; Wi-Fi"),
    ("motherboard", "ASUS TUF GAMING B650-PLUS", "ASUS", 105000, 55, "AM5", "DDR5", "ATX", 0, "AM5; DDR5"),
    ("motherboard", "Gigabyte B760M DS3H DDR4", "Gigabyte", 60000, 50, "LGA1700", "DDR4", "mATX", 0, "LGA1700; DDR4"),
    ("motherboard", "MSI PRO B760-P WIFI DDR5", "MSI", 95000, 55, "LGA1700", "DDR5", "ATX", 0, "LGA1700; DDR5; Wi-Fi"),
    ("ram", "Kingston Fury Beast 16GB (2x8) DDR4", "Kingston", 22000, 6, "", "DDR4", "", 16, "16 ГБ; комплект 2×8 ГБ"),
    ("ram", "Kingston Fury Beast 32GB (2x16) DDR4", "Kingston", 38000, 8, "", "DDR4", "", 32, "32 ГБ; комплект 2×16 ГБ"),
    ("ram", "Kingston Fury Beast 32GB (2x16) DDR5", "Kingston", 52000, 8, "", "DDR5", "", 32, "32 ГБ; комплект 2×16 ГБ"),
    ("ram", "Corsair Vengeance 64GB (2x32) DDR5", "Corsair", 105000, 10, "", "DDR5", "", 64, "64 ГБ; комплект 2×32 ГБ"),
    ("storage", "Samsung 990 EVO 1TB NVMe", "Samsung", 45000, 7, "", "", "", 0, "SSD M.2 NVMe; 1 ТБ"),
    ("storage", "WD Blue SN580 1TB NVMe", "Western Digital", 35000, 6, "", "", "", 0, "SSD M.2 NVMe; 1 ТБ"),
    ("storage", "Kingston NV2 2TB NVMe", "Kingston", 52000, 8, "", "", "", 0, "SSD M.2 NVMe; 2 ТБ"),
    ("storage", "Seagate Barracuda 2TB HDD", "Seagate", 30000, 6, "", "", "", 0, "Жёсткий диск; 2 ТБ"),
    ("psu", "Corsair CV550 550W 80+ Bronze", "Corsair", 35000, 0, "", "", "", 550, "550 Вт; 80+ Bronze"),
    ("psu", "DeepCool PK650D 650W 80+ Bronze", "DeepCool", 42000, 0, "", "", "", 650, "650 Вт; 80+ Bronze"),
    ("psu", "be quiet! Pure Power 12 M 750W", "be quiet!", 85000, 0, "", "", "", 750, "750 Вт; 80+ Gold"),
    ("psu", "Corsair RM850e 850W", "Corsair", 90000, 0, "", "", "", 850, "850 Вт; модульный"),
    ("case", "DeepCool CC560", "DeepCool", 30000, 0, "", "", "ATX", 0, "Корпус с вентиляторами; ATX/mATX"),
    ("case", "NZXT H5 Flow", "NZXT", 55000, 0, "", "", "ATX", 0, "Корпус с продуваемой передней панелью"),
    ("case", "Cooler Master MasterBox Q300L", "Cooler Master", 28000, 0, "", "", "mATX", 0, "Компактный корпус; mATX"),
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with get_db() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS components (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            name TEXT NOT NULL,
            brand TEXT NOT NULL,
            price INTEGER NOT NULL DEFAULT 0,
            power_w INTEGER NOT NULL DEFAULT 0,
            socket TEXT DEFAULT '',
            memory_type TEXT DEFAULT '',
            form_factor TEXT DEFAULT '',
            capacity_gb INTEGER NOT NULL DEFAULT 0,
            description TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS builds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS build_components (
            build_id INTEGER NOT NULL,
            component_id INTEGER NOT NULL,
            PRIMARY KEY(build_id, component_id),
            FOREIGN KEY(build_id) REFERENCES builds(id) ON DELETE CASCADE,
            FOREIGN KEY(component_id) REFERENCES components(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS favorites (
            user_id INTEGER NOT NULL,
            component_id INTEGER NOT NULL,
            PRIMARY KEY(user_id, component_id),
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(component_id) REFERENCES components(id) ON DELETE CASCADE
        );
        """)
        if db.execute("SELECT COUNT(*) FROM components").fetchone()[0] == 0:
            db.executemany("""INSERT INTO components
                (category,name,brand,price,power_w,socket,memory_type,form_factor,capacity_gb,description)
                VALUES (?,?,?,?,?,?,?,?,?,?)""", SEED_COMPONENTS)
        if db.execute("SELECT id FROM users WHERE username = ?", ("admin",)).fetchone() is None:
            db.execute("INSERT INTO users(username,password_hash,is_admin) VALUES(?,?,1)",
                       ("admin", generate_password_hash(os.environ.get("PC_BUILDER_ADMIN_PASSWORD", "Admin123!"))))

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    with get_db() as db:
        row = db.execute("SELECT id,username,is_admin FROM users WHERE id=?", (uid,)).fetchone()
        return dict(row) if row else None

@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "categories": CATEGORIES}

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Сначала войдите в аккаунт.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user:
            flash("Войдите в аккаунт администратора.", "warning")
            return redirect(url_for("login"))
        if not user["is_admin"]:
            abort(403)
        return view(*args, **kwargs)
    return wrapped

def get_component(component_id):
    with get_db() as db:
        row = db.execute("SELECT * FROM components WHERE id=?", (component_id,)).fetchone()
        return dict(row) if row else None

def get_build(build_id, user_id=None):
    with get_db() as db:
        query = """SELECT b.* FROM builds b WHERE b.id=?"""
        params = [build_id]
        if user_id is not None:
            query += " AND b.user_id=?"
            params.append(user_id)
        build = db.execute(query, params).fetchone()
        if not build:
            return None
        items = db.execute("""SELECT c.* FROM components c JOIN build_components bc
                              ON c.id=bc.component_id WHERE bc.build_id=?
                              ORDER BY CASE c.category
                              WHEN 'cpu' THEN 1 WHEN 'motherboard' THEN 2 WHEN 'ram' THEN 3
                              WHEN 'gpu' THEN 4 WHEN 'storage' THEN 5 WHEN 'psu' THEN 6 ELSE 7 END""",
                           (build_id,)).fetchall()
        return {"id": build["id"], "user_id": build["user_id"], "name": build["name"],
                "created_at": build["created_at"], "components": [dict(x) for x in items]}

def build_analysis(items):
    total = sum(int(x["price"]) for x in items)
    power = sum(int(x["power_w"] or 0) for x in items)
    psu = next((x for x in items if x["category"] == "psu"), None)
    cpu = next((x for x in items if x["category"] == "cpu"), None)
    board = next((x for x in items if x["category"] == "motherboard"), None)
    ram = next((x for x in items if x["category"] == "ram"), None)
    case = next((x for x in items if x["category"] == "case"), None)
    gpu = next((x for x in items if x["category"] == "gpu"), None)
    issues = []
    if cpu and board and cpu.get("socket") and board.get("socket") and cpu["socket"] != board["socket"]:
        issues.append(f"Сокет процессора ({cpu['socket']}) не совпадает с сокетом платы ({board['socket']}).")
    if board and ram and board.get("memory_type") and ram.get("memory_type") and board["memory_type"] != ram["memory_type"]:
        issues.append(f"Тип памяти ({ram['memory_type']}) не совпадает с типом памяти платы ({board['memory_type']}).")
    if board and case and board.get("form_factor") and case.get("form_factor"):
        if board["form_factor"] == "ATX" and case["form_factor"] == "mATX":
            issues.append("Плата ATX может не поместиться в корпус, рассчитанный только на mATX.")
    if psu and power > 0 and psu["capacity_gb"] < int(power * 1.25):
        issues.append(f"Блок питания на {psu['capacity_gb']} Вт может быть слабоват: рекомендуемый ориентир — от {int(power * 1.25)} Вт.")
    if not cpu:
        issues.append("Не выбран процессор.")
    if not board:
        issues.append("Не выбрана материнская плата.")
    if not ram:
        issues.append("Не выбрана оперативная память.")
    if not psu:
        issues.append("Не выбран блок питания.")
    if not gpu:
        issues.append("Не выбрана дискретная видеокарта. Убедитесь, что процессор имеет встроенную графику, если она нужна.")
    return {"total": total, "power": power, "recommended_psu": int(power * 1.25) if power else 0,
            "issues": issues, "ok": len(issues) == 0}

@app.route("/")
def index():
    with get_db() as db:
        featured = db.execute("SELECT * FROM components ORDER BY price DESC LIMIT 6").fetchall()
        count_components = db.execute("SELECT COUNT(*) FROM components").fetchone()[0]
        count_builds = db.execute("SELECT COUNT(*) FROM builds").fetchone()[0]
        recent_builds = db.execute("""SELECT b.id,b.name,b.created_at,u.username FROM builds b
                                     JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 4""").fetchall()
    return render_template("index.html", featured=featured, count_components=count_components,
                           count_builds=count_builds, recent_builds=recent_builds)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(username) > 32:
            flash("Логин должен содержать от 3 до 32 символов.", "danger")
        elif len(password) < 8:
            flash("Пароль должен содержать не менее 8 символов.", "danger")
        else:
            try:
                with get_db() as db:
                    db.execute("INSERT INTO users(username,password_hash) VALUES(?,?)",
                               (username, generate_password_hash(password)))
                flash("Аккаунт создан. Теперь войдите.", "success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Такой логин уже существует.", "danger")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with get_db() as db:
            user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Вы успешно вошли.", "success")
            next_url = request.args.get("next", "")
            if next_url.startswith("/") and not next_url.startswith("//"):
                return redirect(next_url)
            return redirect(url_for("profile"))
        flash("Неверный логин или пароль.", "danger")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "info")
    return redirect(url_for("index"))

@app.route("/catalog")
def catalog():
    category = request.args.get("category", "")
    search = request.args.get("q", "").strip()
    sort = request.args.get("sort", "name")
    sql = "SELECT * FROM components WHERE 1=1"
    params = []
    if category in CATEGORIES:
        sql += " AND category=?"
        params.append(category)
    if search:
        sql += " AND (name LIKE ? OR brand LIKE ? OR description LIKE ?)"
        params += [f"%{search}%"] * 3
    order_map = {"name": "name COLLATE NOCASE", "price_asc": "price ASC", "price_desc": "price DESC"}
    sql += " ORDER BY " + order_map.get(sort, "name COLLATE NOCASE")
    with get_db() as db:
        components = db.execute(sql, params).fetchall()
    return render_template("catalog.html", components=components, selected_category=category,
                           search=search, sort=sort)

@app.route("/component/<int:component_id>")
def component_detail(component_id):
    component = get_component(component_id)
    if not component:
        abort(404)
    return render_template("component_form.html", component=component, detail=True)

@app.route("/builder", methods=["GET", "POST"])
def builder():
    if request.method == "POST":
        if not current_user():
            flash("Чтобы сохранить сборку, войдите в аккаунт.", "warning")
            return redirect(url_for("login"))
        name = request.form.get("name", "Моя сборка").strip()[:80] or "Моя сборка"
        ids = []
        for cat in CATEGORY_ORDER:
            raw = request.form.get(f"component_{cat}", "")
            if raw.isdigit() and int(raw) not in ids:
                ids.append(int(raw))
        with get_db() as db:
            valid = []
            for cid in ids:
                row = db.execute("SELECT id FROM components WHERE id=?", (cid,)).fetchone()
                if row:
                    valid.append(cid)
            cur = db.execute("INSERT INTO builds(user_id,name) VALUES(?,?)", (current_user()["id"], name))
            build_id = cur.lastrowid
            db.executemany("INSERT INTO build_components(build_id,component_id) VALUES(?,?)",
                           [(build_id, cid) for cid in valid])
        flash("Сборка сохранена.", "success")
        return redirect(url_for("build_detail", build_id=build_id))
    with get_db() as db:
        items = db.execute("SELECT * FROM components ORDER BY name").fetchall()
    grouped = {cat: [dict(x) for x in items if x["category"] == cat] for cat in CATEGORY_ORDER}
    return render_template("builder.html", grouped=grouped, order=CATEGORY_ORDER)

@app.route("/build/<int:build_id>")
@login_required
def build_detail(build_id):
    build = get_build(build_id, current_user()["id"])
    if not build:
        abort(404)
    analysis = build_analysis(build["components"])
    return render_template("build_detail.html", build=build, analysis=analysis)

@app.route("/build/<int:build_id>/delete", methods=["POST"])
@login_required
def delete_build(build_id):
    with get_db() as db:
        cur = db.execute("DELETE FROM builds WHERE id=? AND user_id=?", (build_id, current_user()["id"]))
        if cur.rowcount:
            flash("Сборка удалена.", "success")
        else:
            flash("Сборка не найдена.", "warning")
    return redirect(url_for("profile"))

@app.route("/compare")
def compare():
    raw_ids = request.args.get("ids", "")
    ids = []
    for item in raw_ids.split(","):
        if item.strip().isdigit() and int(item) not in ids:
            ids.append(int(item))
    ids = ids[:4]
    components = []
    if ids:
        placeholders = ",".join("?" for _ in ids)
        with get_db() as db:
            rows = db.execute(f"SELECT * FROM components WHERE id IN ({placeholders})", ids).fetchall()
        by_id = {x["id"]: dict(x) for x in rows}
        components = [by_id[i] for i in ids if i in by_id]
    return render_template("compare.html", components=components)

@app.route("/favorite/<int:component_id>", methods=["POST"])
@login_required
def favorite(component_id):
    with get_db() as db:
        exists = db.execute("SELECT id FROM components WHERE id=?", (component_id,)).fetchone()
        if not exists:
            abort(404)
        fav = db.execute("SELECT 1 FROM favorites WHERE user_id=? AND component_id=?",
                         (current_user()["id"], component_id)).fetchone()
        if fav:
            db.execute("DELETE FROM favorites WHERE user_id=? AND component_id=?",
                       (current_user()["id"], component_id))
            flash("Удалено из избранного.", "info")
        else:
            db.execute("INSERT INTO favorites(user_id,component_id) VALUES(?,?)",
                       (current_user()["id"], component_id))
            flash("Добавлено в избранное.", "success")
    return redirect(request.referrer or url_for("catalog"))

@app.route("/profile")
@login_required
def profile():
    user = current_user()
    with get_db() as db:
        builds = db.execute("SELECT * FROM builds WHERE user_id=? ORDER BY id DESC", (user["id"],)).fetchall()
        favorites = db.execute("""SELECT c.* FROM components c JOIN favorites f ON c.id=f.component_id
                                  WHERE f.user_id=? ORDER BY c.name""", (user["id"],)).fetchall()
    build_cards = []
    for b in builds:
        full = get_build(b["id"], user["id"])
        full["analysis"] = build_analysis(full["components"])
        build_cards.append(full)
    return render_template("profile.html", builds=build_cards, favorites=favorites)

@app.route("/admin")
@admin_required
def admin():
    with get_db() as db:
        components = db.execute("SELECT * FROM components ORDER BY category,name").fetchall()
        users = db.execute("SELECT id,username,is_admin,created_at FROM users ORDER BY id").fetchall()
        builds_count = db.execute("SELECT COUNT(*) FROM builds").fetchone()[0]
    return render_template("admin.html", components=components, users=users, builds_count=builds_count)

@app.route("/admin/component/new", methods=["GET", "POST"])
@app.route("/admin/component/<int:component_id>/edit", methods=["GET", "POST"])
@admin_required
def admin_component(component_id=None):
    component = get_component(component_id) if component_id else None
    if component_id and not component:
        abort(404)
    if request.method == "POST":
        category = request.form.get("category", "")
        name = request.form.get("name", "").strip()
        brand = request.form.get("brand", "").strip()
        description = request.form.get("description", "").strip()
        try:
            price = max(0, int(request.form.get("price", "0")))
            power_w = max(0, int(request.form.get("power_w", "0")))
            capacity_gb = max(0, int(request.form.get("capacity_gb", "0")))
        except ValueError:
            flash("Цена, мощность и объём должны быть целыми числами.", "danger")
            return render_template("component_form.html", component=component, detail=False)
        if category not in CATEGORIES or not name or not brand:
            flash("Заполните название, бренд и корректную категорию.", "danger")
            return render_template("component_form.html", component=component, detail=False)
        values = (category, name, brand, price, power_w,
                  request.form.get("socket", "").strip(),
                  request.form.get("memory_type", "").strip(),
                  request.form.get("form_factor", "").strip(),
                  capacity_gb, description)
        with get_db() as db:
            if component:
                db.execute("""UPDATE components SET category=?,name=?,brand=?,price=?,power_w=?,
                              socket=?,memory_type=?,form_factor=?,capacity_gb=?,description=? WHERE id=?""",
                           values + (component_id,))
                flash("Комплектующая обновлена.", "success")
            else:
                db.execute("""INSERT INTO components(category,name,brand,price,power_w,socket,memory_type,
                              form_factor,capacity_gb,description) VALUES(?,?,?,?,?,?,?,?,?,?)""", values)
                flash("Комплектующая добавлена.", "success")
        return redirect(url_for("admin"))
    return render_template("component_form.html", component=component, detail=False)

@app.route("/admin/component/<int:component_id>/delete", methods=["POST"])
@admin_required
def admin_delete_component(component_id):
    with get_db() as db:
        db.execute("DELETE FROM components WHERE id=?", (component_id,))
    flash("Комплектующая удалена.", "success")
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("404.html", code=403, message="Недостаточно прав для этой страницы."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("404.html", code=404, message="Страница не найдена."), 404

init_db()

if __name__ == "__main__":
    app.run(debug=True)
