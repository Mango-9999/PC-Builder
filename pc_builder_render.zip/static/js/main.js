document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("form[data-confirm]").forEach(form => {
    form.addEventListener("submit", event => {
      if (!window.confirm(form.dataset.confirm || "Подтвердить действие?")) event.preventDefault();
    });
  });

  const form = document.getElementById("builderForm");
  if (!form) return;
  const selects = [...form.querySelectorAll(".component-select")];
  const totalPrice = document.getElementById("totalPrice");
  const componentCount = document.getElementById("componentCount");
  const powerValue = document.getElementById("powerValue");
  const psuValue = document.getElementById("psuValue");
  const progressBar = document.getElementById("progressBar");
  const box = document.getElementById("compatibilityBox");
  const fmt = value => new Intl.NumberFormat("ru-RU").format(value);
  const selected = () => selects.filter(s => s.value).map(s => {
    const o = s.options[s.selectedIndex];
    return {category:s.dataset.category, id:s.value, name:o.textContent.split(" · ")[0],
      price:Number(o.dataset.price || 0), power:Number(o.dataset.power || 0),
      socket:o.dataset.socket || "", memory:o.dataset.memory || "",
      form:o.dataset.form || "", capacity:Number(o.dataset.capacity || 0)};
  });
  function update() {
    const items = selected();
    const total = items.reduce((sum, x) => sum + x.price, 0);
    const power = items.reduce((sum, x) => sum + x.power, 0);
    const psu = items.find(x => x.category === "psu");
    const cpu = items.find(x => x.category === "cpu");
    const board = items.find(x => x.category === "motherboard");
    const ram = items.find(x => x.category === "ram");
    const gpu = items.find(x => x.category === "gpu");
    const pcCase = items.find(x => x.category === "case");
    const issues = [];
    if (cpu && board && cpu.socket && board.socket && cpu.socket !== board.socket)
      issues.push(`Сокет CPU (${cpu.socket}) не совпадает с платой (${board.socket}).`);
    if (board && ram && board.memory && ram.memory && board.memory !== ram.memory)
      issues.push(`Тип RAM (${ram.memory}) не совпадает с платой (${board.memory}).`);
    if (board && pcCase && board.form === "ATX" && pcCase.form === "mATX")
      issues.push("Плата ATX может не поместиться в корпус mATX.");
    if (psu && power && psu.capacity < power * 1.25)
      issues.push(`Мощности БП может не хватить. Рекомендуемый ориентир: ${Math.ceil(power*1.25)} Вт.`);
    if (!cpu) issues.push("Не выбран процессор.");
    if (!board) issues.push("Не выбрана материнская плата.");
    if (!ram) issues.push("Не выбрана оперативная память.");
    if (!psu) issues.push("Не выбран блок питания.");
    if (!gpu) issues.push("Не выбрана видеокарта.");
    totalPrice.textContent = `${fmt(total)} ₸`;
    componentCount.textContent = `${items.length} / ${selects.length}`;
    powerValue.textContent = `${power} Вт`;
    psuValue.textContent = power ? `${Math.ceil(power*1.25)} Вт` : "—";
    progressBar.style.width = `${items.length / selects.length * 100}%`;
    box.classList.toggle("has-issues", issues.length > 0);
    box.innerHTML = `<strong>${issues.length ? "Нужно проверить" : "Основные проверки пройдены"}</strong>` +
      (issues.length ? `<ul>${issues.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>` : "<p>Явных конфликтов по проверяемым параметрам нет.</p>");
    document.querySelectorAll(".selected-hint").forEach(hint => {
      const item = items.find(x => x.category === hint.dataset.hint);
      hint.textContent = item ? `${item.name} · ${fmt(item.price)} ₸` : "Выбери комплектующую из списка.";
    });
  }
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
  }
  selects.forEach(s => s.addEventListener("change", update));
  update();
});
